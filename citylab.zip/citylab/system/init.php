<?php

require_once 'classes/App.php';
require_once 'classes/Database.php';
require_once 'classes/Model.php';
require_once 'classes/Views.php';
require_once 'classes/Controller.php';

//no need ^ use auto load function

$app = new App();